# Underwater-Image-Enhancement-based-on-Fusion-Python
This is the python version of https://github.com/IsaacChanghau/ImageEnhanceViaFusion based on the paper based on the paper 'Enhancing Underwater Images and Videos by Fusion' . 

Paper:https://ieeexplore.ieee.org/document/6247661
